<?php
include('conect.php');
error_reporting(E_ERROR);
$ter = $_POST['territorio'];

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" type="text/css" href="style.css" media="screen" />
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de territórios</title>
</head>
<body>




<form action="territorios.php?select=1&ter=<?php echo $ter ?>" method="post">
        <select name="territorio" id="territorio">
            <option value=""> Selecione um território</option>
            <?php 
                $query_territorio = mysqli_query( $conn, "SELECT * FROM territorio ORDER BY id_territorio ASC ");
                    while ($row = $query_territorio->fetch_assoc())  {
            ?>
            <option value="<?php echo $row['id_territorio'];?>"><?php echo $row['id_territorio'];?></option>
            <?php } ?>
        </select>
    <input type="submit" value="escolher">
</form>
<?php 

if($_GET['select']){ ?>


<h2>Território <?php echo $ter; ?></h2>
<form action="territorios.php?update=1&select=<?php echo $_GET['select'] ?>" method="post" >
        <?php 
                $query_ter = mysqli_query( $conn, "SELECT * FROM territorio WHERE id_territorio = '".$ter."' ");
                    while ($row = $query_ter->fetch_assoc())  {
                        $publicador = $row['Publicador'];
                        $data = $row['data'];
        ?>
            <ul>
                <li>
                    <lable>Nome</label><br>
                    <input type="text" name="nome" id="" value="<?php if($publicador){echo $publicador;} ?>" size="40px">
                </li>
                <li>
                    <label>Dia que foi trabalhado</label><br>
                    <input type="date" name="data" id="" value="<?php if($data){echo $data;}?>">
                </li>
            <input type="hidden" name="ter" value="<?php echo $ter ?>">
        </ul>
        <?php 
            }
        ?>
        
  

<?php  
    $query_lsita_rua = "SELECT  A.nome_rua, A.id_rua, B.id_territorio FROM rua A INNER JOIN casas B ON A.id_rua = B.id_rua WHERE B.id_territorio = '".$ter."' GROUP BY nome_rua ORDER BY id_rua ASC";
    $lista_rua = mysqli_query($conn, $query_lsita_rua);
?>


<?php

    while ($row_rua = $lista_rua->fetch_assoc())  {
           $nome_rua= $row_rua['nome_rua'];
           $id_rua = $row_rua['id_rua'];
           $id_territorio = $row_rua['id_territorio'];
?>

        <h3><?php echo $nome_rua ?></h3>
        <ul id="list-ter">
            <?php
                $query_casas = mysqli_query( $conn, "SELECT * FROM casas WHERE id_rua = '".$id_rua."' and id_territorio = '".$id_territorio."' ORDER BY CASA ASC");
                while ($row = $query_casas->fetch_assoc())  {
                        $casa = $row['casa'];
                        $tipo = $row['Tipo'] ;
                        $feito = $row['feito'];
            ?>
                <li>
                    <input type="checkbox" name="feito[]" <?php  if($feito == $casa ){ echo "checked";}  ?> value="<?php echo $casa ?>">
                    <input type="hidden" name="casa[]" value="<?php echo $casa ?>">
                    <?php echo $casa ?> <?php echo $tipo;?>
                </li>    
            <?php } ?>
        </ul>

            
<?php  }  ?>

        <input type="submit" value="Atualizar" class="atalizar">
    </form>
<?php } ?>

<?php


/* Update */
if($_GET['update']==1){

    $feito = $_POST['feito'];
    $nome = $_POST['nome'];
    $data = $_POST['data'];
    $ter = $_POST['ter'];

        $valores =  "'".implode("','",$feito)."'";
        
        $update_ter = "UPDATE territorio SET Publicador = '".$nome."', data = '".$data."' WHERE id_territorio = '".$ter."'";
        $query_update_ter = mysqli_query($conn, $update_ter);


        foreach ($feito as $valor) {
        
            $update = "UPDATE casas SET feito = '".$valor."' WHERE casas.casa ='".$valor."'";
            $update . "<br>";
            $query_update = mysqli_query($conn, $update);
        

                $teste ="SELECT * from casas WHERE casa NOT IN ($valores)";
                $teste2 = mysqli_query($conn, $teste);
                while ($row = $teste2->fetch_assoc())  {
                    $id_casa = $row['casa'];
                    $update_null = "UPDATE casas SET feito = '0' WHERE casas.casa ='".$id_casa."'";
                    $query_notin = mysqli_query($conn,  $update_null);
                }

        }
  
        if($query_update){
            echo "<span class='sucess'>Dados atualizados com sucesso<span>";
        }else{
            echo "erro ao atualizar";
        }

    }


?>
</body>
</html>